from typing import Optional, List
from sqlalchemy import select, update, func
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import User, Movie, Favorite


# ==================== USER ====================

async def get_or_create_user(session: AsyncSession, user_id: int, full_name: str = None, username: str = None) -> User:
    result = await session.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        user = User(id=user_id, full_name=full_name, username=username)
        session.add(user)
        await session.commit()
        await session.refresh(user)
    return user


async def update_user_language(session: AsyncSession, user_id: int, language: str):
    await session.execute(
        update(User).where(User.id == user_id).values(language=language)
    )
    await session.commit()


async def get_user_language(session: AsyncSession, user_id: int) -> str:
    result = await session.execute(select(User.language).where(User.id == user_id))
    lang = result.scalar_one_or_none()
    return lang or "uz"


# ==================== MOVIE ====================

async def add_movie(
    session: AsyncSession,
    title: str,
    video_file_id: str,
    year: Optional[str] = None,
    genre: Optional[str] = None,
    language: Optional[str] = None,
    description: Optional[str] = None,
    trailer_url: Optional[str] = None,
    poster_file_id: Optional[str] = None,
    created_by: Optional[int] = None
) -> Movie:
    movie = Movie(
        title=title,
        year=year if year != "-" else None,
        genre=genre if genre != "-" else None,
        language=language if language != "-" else None,
        description=description if description != "-" else None,
        trailer_url=trailer_url if trailer_url != "-" else None,
        poster_file_id=poster_file_id if poster_file_id != "-" else None,
        video_file_id=video_file_id,
        created_by=created_by
    )
    session.add(movie)
    await session.commit()
    await session.refresh(movie)
    return movie


async def get_movie_by_id(session: AsyncSession, movie_id: int) -> Optional[Movie]:
    result = await session.execute(select(Movie).where(Movie.id == movie_id, Movie.is_active == True))
    return result.scalar_one_or_none()


async def search_movies(session: AsyncSession, query: str, limit: int = 20) -> List[Movie]:
    result = await session.execute(
        select(Movie)
        .where(Movie.is_active == True, Movie.title.ilike(f"%{query}%"))
        .order_by(Movie.created_at.desc())
        .limit(limit)
    )
    return result.scalars().all()


async def get_all_movies(session: AsyncSession, limit: int = 50) -> List[Movie]:
    result = await session.execute(
        select(Movie)
        .where(Movie.is_active == True)
        .order_by(Movie.created_at.desc())
        .limit(limit)
    )
    return result.scalars().all()


async def get_random_movie(session: AsyncSession) -> Optional[Movie]:
    result = await session.execute(
        select(Movie)
        .where(Movie.is_active == True)
        .order_by(func.random())
        .limit(1)
    )
    return result.scalar_one_or_none()


async def get_movies_by_genre(session: AsyncSession, genre: str, limit: int = 20) -> List[Movie]:
    result = await session.execute(
        select(Movie)
        .where(Movie.is_active == True, Movie.genre.ilike(f"%{genre}%"))
        .order_by(Movie.created_at.desc())
        .limit(limit)
    )
    return result.scalars().all()


async def increment_views(session: AsyncSession, movie_id: int):
    await session.execute(
        update(Movie).where(Movie.id == movie_id).values(views=Movie.views + 1)
    )
    await session.commit()


async def get_movies_count(session: AsyncSession) -> int:
    result = await session.execute(select(func.count(Movie.id)).where(Movie.is_active == True))
    return result.scalar() or 0


# ==================== FAVORITE ====================

async def add_favorite(session: AsyncSession, user_id: int, movie_id: int) -> bool:
    result = await session.execute(
        select(Favorite).where(Favorite.user_id == user_id, Favorite.movie_id == movie_id)
    )
    if result.scalar_one_or_none():
        return False  # already exists
    fav = Favorite(user_id=user_id, movie_id=movie_id)
    session.add(fav)
    await session.commit()
    return True


async def remove_favorite(session: AsyncSession, user_id: int, movie_id: int):
    result = await session.execute(
        select(Favorite).where(Favorite.user_id == user_id, Favorite.movie_id == movie_id)
    )
    fav = result.scalar_one_or_none()
    if fav:
        await session.delete(fav)
        await session.commit()


async def get_user_favorites(session: AsyncSession, user_id: int) -> List[Movie]:
    result = await session.execute(
        select(Movie)
        .join(Favorite, Favorite.movie_id == Movie.id)
        .where(Favorite.user_id == user_id, Movie.is_active == True)
        .order_by(Favorite.created_at.desc())
    )
    return result.scalars().all()


async def get_top_movies(session: AsyncSession, limit: int = 10) -> List[Movie]:
    result = await session.execute(
        select(Movie)
        .where(Movie.is_active == True)
        .order_by(Movie.views.desc())
        .limit(limit)
    )
    return result.scalars().all()


async def get_users_count(session: AsyncSession) -> int:
    result = await session.execute(select(func.count(User.id)))
    return result.scalar() or 0


async def get_all_user_ids(session: AsyncSession) -> List[int]:
    result = await session.execute(select(User.id))
    return [row[0] for row in result.all()]


async def soft_delete_movie(session: AsyncSession, movie_id: int) -> bool:
    result = await session.execute(select(Movie).where(Movie.id == movie_id))
    movie = result.scalar_one_or_none()
    if not movie:
        return False
    movie.is_active = False
    await session.commit()
    return True
