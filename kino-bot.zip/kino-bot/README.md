# 🎬 Telegram Kino Bot

Mukammal Telegram kino bot — O‘zbek, Rus va Ingliz tillarida.

## Xususiyatlar

- 3 til: O‘zbek | Русский | English
- Admin orqali kino yuklash (video + ma’lumotlar)
- Ixtiyoriy maydonlarni `-` bilan o‘tkazish mumkin
- Qidirish, tasodifiy kino, sevimlilar
- PostgreSQL / SQLite qo‘llab-quvvatlash
- Railway ga deploy qilishga tayyor

## O‘rnatish

1. `pip install -r requirements.txt`
2. `.env` faylini to‘ldiring
3. `python main.py`

## Admin buyruqlari

- Asosiy menyudan **Admin panel** tugmasi
- Kino qo‘shish jarayoni:
  1. Nomi (majburiy)
  2. Yili (`-` bilan o‘tkazish mumkin)
  3. Janr
  4. Til
  5. Tavsif
  6. Treyler linki
  7. Poster
  8. Video (majburiy)

## Railway deploy

1. GitHub ga yuklang
2. Railway da yangi loyiha yarating
3. PostgreSQL qo‘shing
4. Environment variables qo‘shing (`BOT_TOKEN`, `ADMIN_IDS`, `DATABASE_URL`)
