import json
from pathlib import Path

LOCALES_DIR = Path(__file__).parent.parent / "locales"

_cache = {}


def load_locale(lang: str) -> dict:
    if lang not in _cache:
        file_path = LOCALES_DIR / f"{lang}.json"
        if not file_path.exists():
            file_path = LOCALES_DIR / "uz.json"
        with open(file_path, "r", encoding="utf-8") as f:
            _cache[lang] = json.load(f)
    return _cache[lang]


def t(key: str, lang: str = "uz", **kwargs) -> str:
    locale = load_locale(lang)
    text = locale.get(key, key)
    if kwargs:
        try:
            return text.format(**kwargs)
        except KeyError:
            return text
    return text
