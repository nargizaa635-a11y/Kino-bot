from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from utils.i18n import t


def main_menu_kb(lang: str = "uz", is_admin: bool = False) -> ReplyKeyboardMarkup:
    buttons = [
        [KeyboardButton(text=t("search", lang)), KeyboardButton(text=t("random", lang))],
        [KeyboardButton(text=t("genres", lang)), KeyboardButton(text=t("latest", lang))],
        [KeyboardButton(text=t("top", lang)), KeyboardButton(text=t("favorites", lang))],
        [KeyboardButton(text=t("contact_admin", lang)), KeyboardButton(text=t("help", lang))],
    ]
    if is_admin:
        buttons.append([KeyboardButton(text=t("admin_panel", lang))])
    return ReplyKeyboardMarkup(keyboard=buttons, resize_keyboard=True)


def language_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🇺🇿 O‘zbekcha"), KeyboardButton(text="🇷🇺 Русский")],
            [KeyboardButton(text="🇬🇧 English")]
        ],
        resize_keyboard=True,
        one_time_keyboard=True
    )


def cancel_kb(lang: str = "uz") -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text=t("cancel", lang))]],
        resize_keyboard=True
    )


def remove_kb() -> ReplyKeyboardRemove:
    return ReplyKeyboardRemove()
