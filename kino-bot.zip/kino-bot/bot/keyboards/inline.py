from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from utils.i18n import t


def movie_actions_kb(movie_id: int, lang: str = "uz", has_trailer: bool = False) -> InlineKeyboardMarkup:
    buttons = [
        [InlineKeyboardButton(text=t("watch", lang), callback_data=f"watch:{movie_id}")]
    ]
    if has_trailer:
        buttons.append([InlineKeyboardButton(text=t("trailer", lang), callback_data=f"trailer:{movie_id}")])
    buttons.append([
        InlineKeyboardButton(text=t("add_fav", lang), callback_data=f"fav:{movie_id}")
    ])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def admin_kb(lang: str = "uz") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=t("add_movie", lang), callback_data="admin_add_movie")],
        [InlineKeyboardButton(text=t("broadcast", lang), callback_data="admin_broadcast")],
        [InlineKeyboardButton(text=t("stats", lang), callback_data="admin_stats")],
        [InlineKeyboardButton(text=t("delete_movie", lang), callback_data="admin_delete_movie")],
        [InlineKeyboardButton(text=t("back", lang), callback_data="back_main")]
    ])


def genres_kb(lang: str = "uz") -> InlineKeyboardMarkup:
    genres = [
        ("Drama", "Drama"),
        ("Komediya", "Comedy"),
        ("Fantastika", "Sci-Fi"),
        ("Jangari", "Action"),
        ("Qo‘rqinchli", "Horror"),
        ("Melodrama", "Romance"),
        ("Detektiv", "Thriller"),
        ("Multfilm", "Animation"),
    ]
    buttons = []
    row = []
    for i, (name_uz, name_en) in enumerate(genres):
        # Simple: show uz name for all for now, or based on lang
        text = name_uz if lang == "uz" else name_en
        row.append(InlineKeyboardButton(text=text, callback_data=f"genre:{name_en}"))
        if len(row) == 2:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)
    buttons.append([InlineKeyboardButton(text=t("back", lang), callback_data="back_main")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)
