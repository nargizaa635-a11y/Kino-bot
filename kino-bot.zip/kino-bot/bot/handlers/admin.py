from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from sqlalchemy.ext.asyncio import AsyncSession
import asyncio

from config import settings
from database.requests import (
    add_movie, get_movies_count, get_user_language,
    get_users_count, get_all_user_ids, soft_delete_movie
)
from bot.states.movie import AddMovie
from bot.keyboards.reply import cancel_kb, main_menu_kb
from bot.keyboards.inline import admin_kb
from utils.i18n import t

router = Router()


class BroadcastState(StatesGroup):
    waiting_message = State()


class DeleteMovieState(StatesGroup):
    waiting_id = State()


def is_admin(user_id: int) -> bool:
    return user_id in settings.ADMIN_IDS


@router.message(F.text.func(lambda text: text in [
    t("admin_panel", "uz"), t("admin_panel", "ru"), t("admin_panel", "en")
]))
async def admin_panel(message: Message, session: AsyncSession):
    if not is_admin(message.from_user.id):
        return
    lang = await get_user_language(session, message.from_user.id)
    await message.answer(
        t("admin_welcome", lang),
        reply_markup=admin_kb(lang)
    )


@router.callback_query(F.data == "admin_add_movie")
async def start_add_movie(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    if not is_admin(callback.from_user.id):
        await callback.answer("Access denied", show_alert=True)
        return
    lang = await get_user_language(session, callback.from_user.id)
    await state.set_state(AddMovie.title)
    await callback.message.answer(
        t("enter_title", lang),
        reply_markup=cancel_kb(lang)
    )
    await callback.answer()


@router.message(AddMovie.title)
async def process_title(message: Message, state: FSMContext, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    if message.text == t("cancel", lang):
        await state.clear()
        await message.answer(t("cancelled", lang), reply_markup=main_menu_kb(lang, True))
        return
    await state.update_data(title=message.text)
    await state.set_state(AddMovie.year)
    await message.answer(t("enter_year", lang))


@router.message(AddMovie.year)
async def process_year(message: Message, state: FSMContext, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    if message.text == t("cancel", lang):
        await state.clear()
        await message.answer(t("cancelled", lang), reply_markup=main_menu_kb(lang, True))
        return
    await state.update_data(year=message.text)
    await state.set_state(AddMovie.genre)
    await message.answer(t("enter_genre", lang))


@router.message(AddMovie.genre)
async def process_genre(message: Message, state: FSMContext, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    if message.text == t("cancel", lang):
        await state.clear()
        await message.answer(t("cancelled", lang), reply_markup=main_menu_kb(lang, True))
        return
    await state.update_data(genre=message.text)
    await state.set_state(AddMovie.language)
    await message.answer(t("enter_language", lang))


@router.message(AddMovie.language)
async def process_language(message: Message, state: FSMContext, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    if message.text == t("cancel", lang):
        await state.clear()
        await message.answer(t("cancelled", lang), reply_markup=main_menu_kb(lang, True))
        return
    await state.update_data(language=message.text)
    await state.set_state(AddMovie.description)
    await message.answer(t("enter_description", lang))


@router.message(AddMovie.description)
async def process_description(message: Message, state: FSMContext, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    if message.text == t("cancel", lang):
        await state.clear()
        await message.answer(t("cancelled", lang), reply_markup=main_menu_kb(lang, True))
        return
    await state.update_data(description=message.text)
    await state.set_state(AddMovie.trailer)
    await message.answer(t("enter_trailer", lang))


@router.message(AddMovie.trailer)
async def process_trailer(message: Message, state: FSMContext, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    if message.text == t("cancel", lang):
        await state.clear()
        await message.answer(t("cancelled", lang), reply_markup=main_menu_kb(lang, True))
        return
    await state.update_data(trailer=message.text)
    await state.set_state(AddMovie.poster)
    await message.answer(t("enter_poster", lang))


@router.message(AddMovie.poster)
async def process_poster(message: Message, state: FSMContext, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    if message.text and message.text == t("cancel", lang):
        await state.clear()
        await message.answer(t("cancelled", lang), reply_markup=main_menu_kb(lang, True))
        return

    poster_file_id = None
    if message.photo:
        poster_file_id = message.photo[-1].file_id
    elif message.text == "-":
        poster_file_id = "-"
    else:
        await message.answer(t("enter_poster", lang))
        return

    await state.update_data(poster=poster_file_id)
    await state.set_state(AddMovie.video)
    await message.answer(t("enter_video", lang))


@router.message(AddMovie.video)
async def process_video(message: Message, state: FSMContext, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    if message.text and message.text == t("cancel", lang):
        await state.clear()
        await message.answer(t("cancelled", lang), reply_markup=main_menu_kb(lang, True))
        return

    if not message.video and not message.document:
        await message.answer(t("enter_video", lang))
        return

    video_file_id = message.video.file_id if message.video else message.document.file_id
    data = await state.get_data()

    movie = await add_movie(
        session=session,
        title=data["title"],
        year=data.get("year"),
        genre=data.get("genre"),
        language=data.get("language"),
        description=data.get("description"),
        trailer_url=data.get("trailer"),
        poster_file_id=data.get("poster"),
        video_file_id=video_file_id,
        created_by=message.from_user.id
    )

    await state.clear()
    await message.answer(
        t("movie_added", lang) + f"\n\nID: {movie.id}\n🎬 {movie.title}",
        reply_markup=main_menu_kb(lang, True)
    )


# ==================== BROADCAST ====================

@router.callback_query(F.data == "admin_broadcast")
async def start_broadcast(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    if not is_admin(callback.from_user.id):
        await callback.answer("Access denied", show_alert=True)
        return
    lang = await get_user_language(session, callback.from_user.id)
    await state.set_state(BroadcastState.waiting_message)
    await callback.message.answer(
        t("broadcast_prompt", lang),
        reply_markup=cancel_kb(lang)
    )
    await callback.answer()


@router.message(BroadcastState.waiting_message)
async def process_broadcast(message: Message, state: FSMContext, session: AsyncSession, bot: Bot):
    lang = await get_user_language(session, message.from_user.id)
    if message.text and message.text == t("cancel", lang):
        await state.clear()
        await message.answer(t("cancelled", lang), reply_markup=main_menu_kb(lang, True))
        return

    await state.clear()
    await message.answer(t("broadcast_started", lang))

    user_ids = await get_all_user_ids(session)
    total = len(user_ids)
    success = 0
    failed = 0

    for user_id in user_ids:
        try:
            if message.photo:
                await bot.send_photo(
                    chat_id=user_id,
                    photo=message.photo[-1].file_id,
                    caption=message.caption or ""
                )
            else:
                await bot.send_message(chat_id=user_id, text=message.text)
            success += 1
        except Exception:
            failed += 1
        await asyncio.sleep(0.05)  # anti-flood

    await message.answer(
        t("broadcast_done", lang, total=total, success=success, failed=failed),
        reply_markup=main_menu_kb(lang, True)
    )


# ==================== STATS ====================

@router.callback_query(F.data == "admin_stats")
async def admin_stats(callback: CallbackQuery, session: AsyncSession):
    if not is_admin(callback.from_user.id):
        await callback.answer("Access denied", show_alert=True)
        return
    movies = await get_movies_count(session)
    users = await get_users_count(session)
    await callback.message.answer(
        f"📊 Statistika:\n\n"
        f"🎬 Kinolar: {movies}\n"
        f"👥 Foydalanuvchilar: {users}"
    )
    await callback.answer()


# ==================== DELETE MOVIE ====================

@router.callback_query(F.data == "admin_delete_movie")
async def start_delete_movie(callback: CallbackQuery, state: FSMContext, session: AsyncSession):
    if not is_admin(callback.from_user.id):
        await callback.answer("Access denied", show_alert=True)
        return
    lang = await get_user_language(session, callback.from_user.id)
    await state.set_state(DeleteMovieState.waiting_id)
    await callback.message.answer(
        t("enter_movie_id_delete", lang),
        reply_markup=cancel_kb(lang)
    )
    await callback.answer()


@router.message(DeleteMovieState.waiting_id)
async def process_delete_movie(message: Message, state: FSMContext, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    if message.text == t("cancel", lang):
        await state.clear()
        await message.answer(t("cancelled", lang), reply_markup=main_menu_kb(lang, True))
        return

    try:
        movie_id = int(message.text.strip())
    except ValueError:
        await message.answer(t("movie_not_found", lang))
        return

    deleted = await soft_delete_movie(session, movie_id)
    await state.clear()
    if deleted:
        await message.answer(t("movie_deleted", lang), reply_markup=main_menu_kb(lang, True))
    else:
        await message.answer(t("movie_not_found", lang), reply_markup=main_menu_kb(lang, True))
