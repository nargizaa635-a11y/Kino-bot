from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings
from database.requests import (
    get_or_create_user, update_user_language, get_user_language,
    search_movies, get_random_movie, get_all_movies, get_movie_by_id,
    increment_views, add_favorite, get_user_favorites,
    get_top_movies, get_movies_by_genre
)
from bot.keyboards.reply import main_menu_kb, language_kb, cancel_kb
from bot.keyboards.inline import movie_actions_kb, genres_kb
from utils.i18n import t

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message, session: AsyncSession, state: FSMContext):
    await state.clear()
    await get_or_create_user(
        session,
        user_id=message.from_user.id,
        full_name=message.from_user.full_name,
        username=message.from_user.username
    )
    user_lang = await get_user_language(session, message.from_user.id)
    await message.answer(
        t("start", user_lang),
        reply_markup=language_kb()
    )


@router.message(F.text.in_(["🇺🇿 O‘zbekcha", "🇷🇺 Русский", "🇬🇧 English"]))
async def set_language(message: Message, session: AsyncSession):
    lang_map = {
        "🇺🇿 O‘zbekcha": "uz",
        "🇷🇺 Русский": "ru",
        "🇬🇧 English": "en"
    }
    lang = lang_map.get(message.text, "uz")
    await update_user_language(session, message.from_user.id, lang)
    is_admin = message.from_user.id in settings.ADMIN_IDS
    await message.answer(
        t("language_set", lang),
        reply_markup=main_menu_kb(lang, is_admin)
    )


@router.message(F.text.func(lambda text: text in [
    t("search", "uz"), t("search", "ru"), t("search", "en")
]))
async def search_start(message: Message, session: AsyncSession, state: FSMContext):
    lang = await get_user_language(session, message.from_user.id)
    await message.answer(t("search_prompt", lang))
    await state.set_state("searching")


@router.message(F.text.func(lambda text: text in [
    t("random", "uz"), t("random", "ru"), t("random", "en")
]))
async def random_movie(message: Message, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    movie = await get_random_movie(session)
    if not movie:
        await message.answer(t("no_movies", lang))
        return
    await send_movie_card(message, movie, lang, session)


@router.message(F.text.func(lambda text: text in [
    t("latest", "uz"), t("latest", "ru"), t("latest", "en")
]))
async def latest_movies(message: Message, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    movies = await get_all_movies(session, limit=10)
    if not movies:
        await message.answer(t("no_movies", lang))
        return
    for movie in movies:
        await send_movie_card(message, movie, lang, session)


@router.message(F.text.func(lambda text: text in [
    t("top", "uz"), t("top", "ru"), t("top", "en")
]))
async def top_movies(message: Message, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    movies = await get_top_movies(session, limit=10)
    if not movies:
        await message.answer(t("no_movies", lang))
        return
    await message.answer(t("top_movies", lang))
    for movie in movies:
        await send_movie_card(message, movie, lang, session)


@router.message(F.text.func(lambda text: text in [
    t("favorites", "uz"), t("favorites", "ru"), t("favorites", "en")
]))
async def show_favorites(message: Message, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    movies = await get_user_favorites(session, message.from_user.id)
    if not movies:
        await message.answer(t("no_movies", lang))
        return
    for movie in movies:
        await send_movie_card(message, movie, lang, session)


@router.message(F.text.func(lambda text: text in [
    t("genres", "uz"), t("genres", "ru"), t("genres", "en")
]))
async def show_genres(message: Message, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    await message.answer(
        t("choose_genre", lang),
        reply_markup=genres_kb(lang)
    )


@router.message(F.text.func(lambda text: text in [
    t("help", "uz"), t("help", "ru"), t("help", "en")
]))
async def show_help(message: Message, session: AsyncSession):
    lang = await get_user_language(session, message.from_user.id)
    await message.answer(t("help_text", lang), parse_mode="HTML")


@router.message(F.state == "searching")
async def process_search(message: Message, session: AsyncSession, state: FSMContext):
    lang = await get_user_language(session, message.from_user.id)
    query = message.text.strip()
    movies = await search_movies(session, query)
    await state.clear()
    if not movies:
        await message.answer(t("not_found", lang))
        return
    for movie in movies[:10]:
        await send_movie_card(message, movie, lang, session)


@router.callback_query(F.data.startswith("genre:"))
async def process_genre(callback: CallbackQuery, session: AsyncSession):
    genre = callback.data.split(":")[1]
    lang = await get_user_language(session, callback.from_user.id)
    movies = await get_movies_by_genre(session, genre, limit=15)
    if not movies:
        await callback.message.answer(t("not_found", lang))
    else:
        for movie in movies:
            await send_movie_card(callback.message, movie, lang, session)
    await callback.answer()


async def send_movie_card(message: Message, movie, lang: str, session: AsyncSession):
    text = t(
        "movie_info", lang,
        title=movie.title,
        year=movie.year or "-",
        genre=movie.genre or "-",
        language=movie.language or "-",
        views=movie.views,
        description=movie.description or "-"
    )
    kb = movie_actions_kb(movie.id, lang, has_trailer=bool(movie.trailer_url and movie.trailer_url != "-"))
    if movie.poster_file_id and movie.poster_file_id != "-":
        await message.answer_photo(
            photo=movie.poster_file_id,
            caption=text,
            reply_markup=kb,
            parse_mode="HTML"
        )
    else:
        await message.answer(text, reply_markup=kb, parse_mode="HTML")


@router.callback_query(F.data.startswith("watch:"))
async def watch_movie(callback: CallbackQuery, session: AsyncSession):
    movie_id = int(callback.data.split(":")[1])
    movie = await get_movie_by_id(session, movie_id)
    if not movie:
        await callback.answer("Not found", show_alert=True)
        return
    await increment_views(session, movie_id)
    await callback.message.answer_video(
        video=movie.video_file_id,
        caption=f"🎬 {movie.title}"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("trailer:"))
async def show_trailer(callback: CallbackQuery, session: AsyncSession):
    movie_id = int(callback.data.split(":")[1])
    movie = await get_movie_by_id(session, movie_id)
    if not movie or not movie.trailer_url or movie.trailer_url == "-":
        await callback.answer("No trailer", show_alert=True)
        return
    await callback.message.answer(f"🎞 Treyler:\n{movie.trailer_url}")
    await callback.answer()


@router.callback_query(F.data.startswith("fav:"))
async def add_to_fav(callback: CallbackQuery, session: AsyncSession):
    movie_id = int(callback.data.split(":")[1])
    added = await add_favorite(session, callback.from_user.id, movie_id)
    if added:
        await callback.answer("✅ Qo‘shildi!", show_alert=True)
    else:
        await callback.answer("Allaqachon sevimlilarda", show_alert=True)


@router.callback_query(F.data == "back_main")
async def back_to_main(callback: CallbackQuery, session: AsyncSession):
    lang = await get_user_language(session, callback.from_user.id)
    is_admin = callback.from_user.id in settings.ADMIN_IDS
    await callback.message.answer(
        t("main_menu", lang),
        reply_markup=main_menu_kb(lang, is_admin)
    )
    await callback.answer()


# ==================== CONTACT ADMIN ====================

@router.message(F.text.func(lambda text: text in [
    t("contact_admin", "uz"), t("contact_admin", "ru"), t("contact_admin", "en")
]))
async def contact_admin_start(message: Message, session: AsyncSession, state: FSMContext):
    lang = await get_user_language(session, message.from_user.id)
    await message.answer(
        t("contact_prompt", lang),
        reply_markup=cancel_kb(lang)
    )
    await state.set_state("waiting_contact")


@router.message(F.state == "waiting_contact")
async def process_contact(message: Message, session: AsyncSession, state: FSMContext, bot: Bot):
    lang = await get_user_language(session, message.from_user.id)

    if message.text and message.text == t("cancel", lang):
        await state.clear()
        is_admin = message.from_user.id in settings.ADMIN_IDS
        await message.answer(t("cancelled", lang), reply_markup=main_menu_kb(lang, is_admin))
        return

    await state.clear()

    is_admin = message.from_user.id in settings.ADMIN_IDS
    await message.answer(
        t("contact_sent", lang),
        reply_markup=main_menu_kb(lang, is_admin)
    )

    username = message.from_user.username or "yo‘q"
    text_to_admin = t(
        "contact_from_user", "uz",
        name=message.from_user.full_name,
        user_id=message.from_user.id,
        username=username,
        text=message.text or "(media)"
    )

    for admin_id in settings.ADMIN_IDS:
        try:
            if message.photo:
                await bot.send_photo(
                    chat_id=admin_id,
                    photo=message.photo[-1].file_id,
                    caption=text_to_admin
                )
            elif message.video:
                await bot.send_video(
                    chat_id=admin_id,
                    video=message.video.file_id,
                    caption=text_to_admin
                )
            else:
                await bot.send_message(chat_id=admin_id, text=text_to_admin)
        except Exception:
            pass
