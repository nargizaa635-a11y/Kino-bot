from aiogram.fsm.state import State, StatesGroup


class AddMovie(StatesGroup):
    title = State()
    year = State()
    genre = State()
    language = State()
    description = State()
    trailer = State()
    poster = State()
    video = State()
